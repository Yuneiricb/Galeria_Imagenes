<?php
    session_start();
    $picture = $_POST["picture"];
    $ruta_imagenes = "media/";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo "Galería: $picture" ?></title>
        <style>
            body {
                font-family: "Lucida Console", Courier, monospace;
                background-color: #ffd1dc; /* Fondo rosa pastel */
                margin: 0;
                padding: 0;
                display: flex;
                flex-direction: column;
                min-height: 100vh;
                align-items: center;
                justify-content: center;
                color: #333;
            }

            nav {
                width: 100%;
                padding: 20px;
                background-color: #ffffff;
                border-bottom: 2px solid #ff69b4;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                text-align: center;
            }

            nav h1 {
                margin: 0;
                font-size: 24px;
                color: #ff69b4;
            }

            nav .menu {
                margin-top: 10px;
            }

            nav a {
                margin: 0 10px;
                text-decoration: none;
                color: #ff69b4;
                font-weight: bold;
                transition: color 0.3s ease;
            }

            nav a:hover {
                color: #e6007e;
            }

            h1, h2 {
                margin: 10px 0;
                color: #ff69b4;
            }

            .picCont {
                display: flex;
                flex-direction: column;
                align-items: center;
                padding: 20px;
                background-color: #fff;
                border: 2px solid #ff69b4;
                border-radius: 12px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                max-width: 600px;
            }

            img {
                max-width: 100%;
                height: auto;
                border: 2px solid #ff69b4;
                border-radius: 12px;
                margin-top: 20px;
            }

            a {
                text-decoration: none;
            }

            a img {
                transition: transform 0.3s ease;
            }

            a img:hover {
                transform: scale(1.05);
            }
        </style>
    </head>
    <body>
        <nav>
            <a href="index.php"><h1>Galería de imágenes</h1></a>
            <br>
            <section class="menu">
                <?php if( isset( $_SESSION["usuario"] ) && isset( $_SESSION["plan"] ) ) { ?>
                    <a href="logout.php">Cerrar sesión</a>
                    <a href="upload.php">Subir imágenes</a>
                <?php } else if( isset( $_SESSION["usuario"] ) ) { ?>
                    <a href="logout.php">Cerrar sesión</a>
                <?php } else { ?>
                    <h4>Inicia sesión para que se muestre el usuario</h4>
                    <a href="login.php">Iniciar sesión</a>
                    <a href="singUp.php">Registrarse</a>
                <?php } ?>
            </section>
        </nav>

        <section class="picCont">
            <?php
                $usuarioo = $_SESSION["usuario"];
                if (isset($_POST["picture"])) {
                    echo "
                        <h1>$picture</h1>
                        <h2>$usuarioo</h2>
                        <a href='$ruta_imagenes$picture' download='$picture'>
                            <img src='$ruta_imagenes$picture' alt='Imagen'>
                        </a>
                    ";
                } else {
                    header("Location: index.php");
                }
            ?>
        </section>
    </body>
</html>
