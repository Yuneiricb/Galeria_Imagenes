<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galería</title>
    <style>
        body {
            margin: 0;
            font-family: "Lucida Console", Courier, monospace;
            background-color: #f0f0f0;
            color: #000;
            padding-top: 60px;
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 30px;
            background-color: #ffd1dc;
            color: #fff;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .header-left h1 {
            font-size: 24px;
            margin: 0;
            color: #000;
        }

        .menu {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .menu a {
            color: #000;
            text-decoration: none;
            font-weight: bold;
            padding: 8px 16px;
            border-radius: 5px;
            background-color: #555;
            transition: background-color 0.3s;
        }

        .menu a:hover {
            background-color: #888;
        }

        .upload-form {
            max-width: 600px;
            margin: 30px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .upload-form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .upload-form input[type="file"] {
            display: block;
            margin-bottom: 10px;
        }

        .upload-form input[type="submit"] {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .upload-form input[type="submit"]:hover {
            background-color: #218838;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            padding: 20px;
            margin: 0 auto;
            max-width: 1200px;
        }

        .grid form {
            border: none;
            background: none;
            padding: 0;
            margin: 0;
        }

        .grid img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .grid img:hover {
            transform: scale(1.05);
            box-shadow: 0 0 25px rgba(0,0,0,0.5);
        }

        footer {
            background-color: #444;
            color: #fff;
            text-align: center;
            padding: 20px;
            position: fixed;
            width: 100%;
            bottom: 0;
            left: 0;
        }
    </style>
</head>
<body>
    <div class="header-content">
        <div class="header-left">
            <h1>Mi Galería</h1>
        </div>
        <div class="menu">
            <?php if (isset($_SESSION["usuario"]) && isset($_SESSION["plan"])) { ?>
                <span>Bienvenido, <?php echo $_SESSION["usuario"]; ?></span>
                <a href="logout.php">Cerrar sesión</a>
            <?php } else if (isset($_SESSION["usuario"])) { ?>
                <span>Bienvenido, <?php echo $_SESSION["usuario"]; ?></span>
                <a href="logout.php">Cerrar sesión</a>
                <a href="plans.php">Elegir plan</a>
            <?php } else { ?>
                <a href="login.php">Entrar</a>
                <a href="plans.php">Planes</a>
            <?php } ?>
        </div>
    </div>

    <?php if (isset($_SESSION["usuario"]) && isset($_SESSION["plan"])) { ?>
        <div class="upload-form">
            <form action="uploadImage.php" method="post" enctype="multipart/form-data">
                <label for="image">Selecciona una imagen para subir:</label>
                <input type="file" name="image" id="image" accept="image/*" required>
                <input type="submit" value="Subir Imagen">
            </form>
        </div>
    <?php } ?>

    <section class="grid">
        <?php
            global $ruta_imagenes;
            $ruta_imagenes = "media/";
            $imagenes = opendir($ruta_imagenes);
            $hay_imagenes = false;
            if ($imagenes) {
                while ($imagen = readdir($imagenes)) {
                    if (is_file($ruta_imagenes . $imagen) && getimagesize($ruta_imagenes . $imagen)) {
                        echo "<form action='visualizer.php' method='post'>
                                <input type='hidden' name='picture' value='$imagen'>
                                <button type='submit'><img src='$ruta_imagenes$imagen' alt='Imagen'></button>
                              </form>";
                        $hay_imagenes = true;
                    }
                }
                closedir($imagenes);
            } else {
                echo "<p>Error: al cargar carpeta de imágenes</p>";
            }
            if (!$hay_imagenes) {
                echo "<p>No hay imágenes aún. Sube la primera imagen.</p>";
            }
        ?>
    </section>

</body>
</html>
