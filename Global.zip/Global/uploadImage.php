<?php
session_start();

if (!isset($_SESSION["usuario"]) || !isset($_SESSION["plan"])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileSize = $_FILES['image']['size'];
        $fileType = $_FILES['image']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

       
        $allowedExts = array('jpg', 'jpeg', 'png', 'gif');
        
        if (in_array($fileExtension, $allowedExts)) {
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $uploadFileDir = './media/';
            $dest_path = $uploadFileDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                echo 'La imagen se ha subido correctamente.';
            } else {
                echo 'Error al mover la imagen a la carpeta de destino.';
            }
        } else {
            echo 'Tipo de archivo no permitido.';
        }
    } else {
        echo 'No se ha subido ninguna imagen o ha ocurrido un error.';
    }
}
?>

