<?php
session_start();
if (isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In</title>
    
    <link rel="stylesheet" href="styles/login.css">

    <style>
    body {
        font-family: "Lucida Console", Courier, monospace;
        background-color: #ffd1dc; 
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }

    nav {
        position: absolute;
        top: 20px;
        width: 100%;
        text-align: center;
    }

    nav h1 {
        margin: 0;
        color: #000000;
        font-size: 50px;
    }

    .menu a {
        margin: 0 15px;
        text-decoration: none;
        color: #000000;
        font-weight: bold;
    }

    .menu a:hover {
        text-decoration: underline;
    }

    form {
        max-width: 400px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        z-index: 10;
    }

    label, input {
        display: block;
        width: 100%;
        margin-bottom: 10px;
    }

    label {
        font-weight: bold;
    }

    input[type="text"], input[type="password"] {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    input[type="submit"] {
        background-color: #ff1493;
        color: white;
        border: none;
        padding: 10px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }

    input[type="submit"]:hover {
        background-color: #e6007e;
    }
    </style>
</head>
<body>
    <nav>
        <a href="index.php"><h1>Galería</h1></a>
    </nav>
    <form action="loginAuth.php" method="post">
        <label for="user">Nombre</label>
        <input type="text" name="user" id="user" required>
        <label for="password">Contraseña</label>
        <input type="password" name="password" id="password" required>
        <input type="submit" value="Ingresar">
    </form>
</body>
</html>
