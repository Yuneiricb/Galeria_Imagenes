<?php

session_start();
if( isset($_SESSION["usuario"])){ header("location: index.php"); }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <style>
        body {
            background-image: url("fondo/por.jpg");
            font-family: "Lucida Console", Courier, monospace;
            background-color: #000;
            margin: 0;
            padding: 0;
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
        }
        nav {
            position: absolute;
            top: 40px;
            width: 100%;
            text-align: center;
        }
        nav h1 {
            font-size: 45px;
            color: #000; 
            margin: 0;
        }
        nav a{
            font-size: 20px;
        }
        form {
            max-width: 350px; 
            margin: 0 auto; 
            padding: 20px; 
            border: 1px solid #ccc; 
            background-color: #fff;
            border-radius: 10px; 
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label, input {
            display: block;
            margin-bottom: 10px;
            width: 100%;
        }
        input[type="submit"] {
            background-color: #ff1493;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <nav>
        <a href="index.php"><h1>Galería de imágenes</h1></a>
        <br>
        <section class="menu">
            <a href="login.php">Entrar</a>
            <a href="plans.php">Planes</a>
        </section>
    </nav>
    <form action="signUpAuth.php" method="post">
        <label for="user">Ingresa tu nombre de usuario</label>
        <input type="text" name="user" id="user" required> 
        <label for="email">Ingresa tu correo</label> 
        <input type="email" name="email" id="email" required> 
        <label for="pass">Ingresa una Contraseña</label> 
        <input type="password" name="pass" id="pass" required> 
        <input type="submit" value="Registrar">
    </form>
</body>
</html>
