<?php
session_start();
$users = [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $user = trim($_POST['user']);
    $email = trim($_POST['email']);
    $pass = trim($_POST['pass']);

    $users[] = [
        'user' => $user,
        'email' => $email,
        'password' => password_hash($pass, PASSWORD_DEFAULT) // Encriptando la contraseña
    ];

    // Iniciar la sesión para el usuario registrado
    $_SESSION['usuario'] = $user;

    // Redirigir al index
    header("Location: index.php");
    exit();
}
?>
