<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planes</title>

    <style>
        body {
            font-family: "Lucida Console", Courier, monospace;
            background-color: #ffe6e6; /* Fondo rosa pastel */
            color: #333;
            margin: 0;
            padding: 0;
            background-size: cover;
            background-attachment: fixed;
        }
        nav {
            background-color: #ffcccc; /* Tono más oscuro del rosa pastel */
            padding: 15px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        nav h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        nav .menu {
            margin-top: 10px;
        }
        nav a {
            color: #333;
            text-decoration: none;
            margin: 0 10px;
            font-weight: bold;
        }
        h1 {
            text-align: center;
            font-size: 32px;
            margin-top: 20px;
            color: #333;
        }
        p {
            text-align: center;
            font-size: 18px;
            margin: 10px auto 20px auto;
            width: 80%;
            max-width: 600px;
            color: #555;
        }
        .planGrid {
            display: flex;
            justify-content: center;
            padding: 50px;
            gap: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .planBody {
            padding: 20px;
            border: 2px solid #ff9999; /* Tono más oscuro del rosa pastel */
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            width: 250px;
            text-align: center;
        }
        .planBody:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .planBody h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #ff6666; /* Tono más oscuro del rosa pastel */
        }
        .planBody p {
            font-size: 16px;
            margin: 10px 0;
            color: #666;
        }
        button {
            background-color: transparent;
            border: none;
            cursor: pointer;
        }
        button:disabled {
            cursor: not-allowed;
            opacity: 0.6;
        }
        button:disabled .planBody {
            border-color: #ddd;
            color: #ccc;
        }
    </style>
</head>
<body>
    <nav>
        <a href="index.php"><h1>Galería de imágenes</h1></a>
        <section class="menu">
        <?php if( isset( $_SESSION[ "usuario" ] ) && isset( $_SESSION[ "plan" ] ) ) { ?>
        
            <a href="logout.php">Cerrar sesión</a>
            <a href="upload.php">Subir</a>

        <?php } else if( isset( $_SESSION[ "usuario" ] ) ) { ?>

            <a href="logout.php">Cerrar sesión</a>

        <?php } else { ?>

            <a href="login.php">Entrar</a>
            <a href="singUp.php">Registrarse</a>
        <?php } ?>
        </section>
    </nav>

    <h1>Nuestros planes</h1>
    <p>Elige una opción para continuar</p>

    <!--session & plan - upgrade-->
    <?php if( isset( $_SESSION[ "usuario" ] ) && isset( $_SESSION[ "plan" ] ) == true ) { ?>

        <p style="text-align: center;">¡Mejora tu plan actual!</p>
        <section class="planGrid">
            <form>
                <input type="hidden" name="plan">
                <button type='submit' disabled>
                    <section class="planBody">
                        <h2>Estándar</h2>
                        <p>Capacidad para subir hasta 5 imágenes en resolución estándar</p>
                        <p>¡Ya es tuyo!</p>
                    </section>
                </button>
            </form>

            <form action="planManager.php"  method="post">
                <input type="hidden" name="plan" value="upgradeToAtia">
                <button type='submit'>
                    <section class="planBody">
                        <h2>Premium</h2>
                        <p>Capacidad para subir hasta 10 imágenes de alta resolución</p>
                    </section>
                </button>
            </form>
        </section>

    <!--session - get a plan-->
    <?php } else if(isset($_SESSION["usuario"])) { ?>
        
        <p style="text-align: center;">¡Obtener un plan!</p>
        <section class="planGrid">
            <form action="planManager.php" method="post">
                <input type="hidden" name="plan" value="getHymba">
                <button type='submit'>
                    <section class="planBody">
                        <h2>Estándar</h2>
                        <p>Capacidad para subir hasta 5 imágenes en resolución estándar</p>
                    </section>
                </button>
            </form>

            <form action="planManager.php" method="post">
                <input type="hidden" name="plan" value="getAtia">
                <button type='submit'>
                    <section class="planBody">
                        <h2>Premium</h2>
                        <p>Capacidad para subir hasta 10 imágenes de alta resolución</p>
                    </section>
                </button>
            </form>
        </section>

    <!--s & p !! - showcase -->
    <?php } else { ?>

        <p style="text-align: center;">Necesitas tener una cuenta para obtener un plan, <a href="singUp.php">¡Regístrate!</a></p>
        <section class="planGrid">
            <form>
                <input type="hidden" name="plan">
                <button type='submit' disabled>
                    <section class="planBody">
                        <h2>Estándar</h2>
                        <p>Capacidad para subir hasta 5 imágenes en resolución estándar</p>
                    </section>
                </button>
            </form>

            <form action="">
                <input type="hidden" name="plan">
                <button type='submit' disabled>
                    <section class="planBody">
                        <h2>Premium</h2>
                        <p>Capacidad para subir hasta 10 imágenes de alta resolución</p>
                    </section>
                </button>
            </form>
        </section>

    <?php } ?>
</body>
</html>
